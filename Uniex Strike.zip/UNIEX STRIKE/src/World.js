import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { Enemy } from './Enemy.js';
import { Pickup } from './Pickup.js';

export class World {
    constructor(physics, player) {
        this.physics = physics;
        this.player = player;
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x87CEEB); // Sky blue
        this.scene.fog = new THREE.Fog(0x87CEEB, 0, 50);

        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        this.scene.add(this.camera);

        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.shadowMap.enabled = true;
        document.getElementById('game-container').appendChild(this.renderer.domElement);

        this.enemies = [];
        this.pickups = [];
        this.victoryShown = false; // Flag to prevent multiple victory messages

        this.setupLights();
        this.createMap();

        window.addEventListener('resize', () => this.onWindowResize(), false);
    }

    setPlayer(player) {
        this.player = player;
        this.spawnEnemies();
        this.spawnPickups();
    }

    spawnEnemies() {
        // Strategic spawn positions spread across the map
        const spawnZones = [
            { x: 20, z: 20 },   // North-East
            { x: -20, z: 20 },  // North-West
            { x: 20, z: -20 },  // South-East
            { x: -20, z: -20 }, // South-West
            { x: 30, z: 0 },    // East
            { x: -30, z: 0 },   // West
            { x: 0, z: 30 },    // North
            { x: 0, z: -30 }    // South
        ];

        for (let i = 0; i < 15; i++) {
            const zone = spawnZones[i % spawnZones.length];
            const pos = {
                x: zone.x + (Math.random() - 0.5) * 8, // Small variation within zone
                y: 5,
                z: zone.z + (Math.random() - 0.5) * 8
            };
            const enemy = new Enemy(this, this.physics, this.player, pos);
            this.enemies.push(enemy);
        }
    }

    spawnPickups() {
        // Spawn ammo pickups - increased from 8 to 15
        for (let i = 0; i < 15; i++) {
            const pos = {
                x: (Math.random() - 0.5) * 45,
                y: 1,
                z: (Math.random() - 0.5) * 45
            };
            const pickup = new Pickup(this, this.physics, pos, 'ammo');
            this.pickups.push(pickup);
        }

        // Spawn health pickups - increased from 5 to 10
        for (let i = 0; i < 10; i++) {
            const pos = {
                x: (Math.random() - 0.5) * 45,
                y: 1,
                z: (Math.random() - 0.5) * 45
            };
            const pickup = new Pickup(this, this.physics, pos, 'health');
            this.pickups.push(pickup);
        }

        // Spawn shield pickups - increased from 5 to 8
        for (let i = 0; i < 8; i++) {
            const pos = {
                x: (Math.random() - 0.5) * 45,
                y: 1,
                z: (Math.random() - 0.5) * 45
            };
            const pickup = new Pickup(this, this.physics, pos, 'shield');
            this.pickups.push(pickup);
        }
    }

    update(dt) {
        // Update enemies
        this.enemies.forEach(enemy => enemy.update(dt));
        // Remove dead enemies
        const initialEnemyCount = this.enemies.length;
        this.enemies = this.enemies.filter(e => !e.isDead);
        const enemiesKilled = initialEnemyCount - this.enemies.length;

        // Check for victory condition
        if (this.enemies.length === 0 && initialEnemyCount > 0 && !this.victoryShown) {
            console.log('Victory condition met! Showing victory message.');
            console.log(`Initial enemies: ${initialEnemyCount}, Current enemies: ${this.enemies.length}`);
            this.victoryShown = true;
            this.showVictory();
        }

        // Update pickups (they handle their own respawn logic)
        this.pickups.forEach(pickup => {
            pickup.update(dt);
            pickup.checkPlayerCollision(this.player);
        });
    }

    setupLights() {
        const ambientLight = new THREE.AmbientLight(0x404040, 0.5); // Soft white light
        this.scene.add(ambientLight);

        const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
        dirLight.position.set(10, 20, 10);
        dirLight.castShadow = true;
        dirLight.shadow.camera.top = 20;
        dirLight.shadow.camera.bottom = -20;
        dirLight.shadow.camera.left = -20;
        dirLight.shadow.camera.right = 20;
        this.scene.add(dirLight);
    }

    createMap() {
        // Floor
        const floorGeometry = new THREE.PlaneGeometry(100, 100);
        const floorMaterial = new THREE.MeshStandardMaterial({
            color: 0x2a4a2a, // Tactical green
            roughness: 0.9,
            metalness: 0.1
        });
        const floor = new THREE.Mesh(floorGeometry, floorMaterial);
        floor.rotation.x = -Math.PI / 2;
        floor.receiveShadow = true;
        this.scene.add(floor);

        // Physics Floor
        const floorShape = new CANNON.Plane();
        const floorBody = new CANNON.Body({
            mass: 0, // Static
            shape: floorShape,
            material: this.physics.defaultMaterial
        });
        floorBody.quaternion.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), -Math.PI / 2);
        this.physics.world.addBody(floorBody);

        // Create tactical structures
        this.createTacticalStructures();
    }

    createTacticalStructures() {
        // Perimeter walls
        this.createWall({ x: 0, y: 2, z: 45 }, { x: 90, y: 4, z: 1 }); // North wall
        this.createWall({ x: 0, y: 2, z: -45 }, { x: 90, y: 4, z: 1 }); // South wall
        this.createWall({ x: 45, y: 2, z: 0 }, { x: 1, y: 4, z: 90 }); // East wall
        this.createWall({ x: -45, y: 2, z: 0 }, { x: 1, y: 4, z: 90 }); // West wall

        // Central structures
        this.createBunker({ x: 0, y: 0, z: 0 }); // Center bunker

        // Corner bunkers
        this.createBunker({ x: 25, y: 0, z: 25 });   // NE
        this.createBunker({ x: -25, y: 0, z: 25 });  // NW
        this.createBunker({ x: 25, y: 0, z: -25 });  // SE
        this.createBunker({ x: -25, y: 0, z: -25 }); // SW

        // Additional medium bunkers in strategic positions
        this.createBunker({ x: 15, y: 0, z: 15 });
        this.createBunker({ x: -15, y: 0, z: 15 });
        this.createBunker({ x: 15, y: 0, z: -15 });

        // Add more covers throughout the map
        for (let i = 0; i < 15; i++) {
            const posX = (Math.random() - 0.5) * 80;
            const posZ = (Math.random() - 0.5) * 80;
            this.createCover({ x: posX, y: 0, z: posZ });
        }

        // Add crates for more cover options
        for (let i = 0; i < 10; i++) {
            const posX = (Math.random() - 0.5) * 70;
            const posZ = (Math.random() - 0.5) * 70;
            const sizeX = 1 + Math.random() * 2;
            const sizeY = 1 + Math.random() * 1.5;
            const sizeZ = 1 + Math.random() * 2;
            this.createCrate(
                { x: posX, y: sizeY / 2, z: posZ },
                { x: sizeX, y: sizeY, z: sizeZ }
            );
        }

        // Add some pillars for vertical cover
        for (let i = 0; i < 8; i++) {
            const angle = (i / 8) * Math.PI * 2;
            const radius = 20;
            const posX = Math.cos(angle) * radius;
            const posZ = Math.sin(angle) * radius;
            this.createWall(
                { x: posX, y: 3, z: posZ },
                { x: 1, y: 6, z: 1 }
            );
        }
    }

    createCrate(position, size) {
        const geometry = new THREE.BoxGeometry(size.x, size.y, size.z);
        const material = new THREE.MeshStandardMaterial({ color: 0x8B4513 });
        const crate = new THREE.Mesh(geometry, material);
        crate.position.set(position.x, position.y, position.z);
        crate.castShadow = true;
        crate.receiveShadow = true;
        this.scene.add(crate);

        // Physics for crates
        const crateShape = new CANNON.Box(new CANNON.Vec3(size.x / 2, size.y / 2, size.z / 2));
        const crateBody = new CANNON.Body({
            mass: 0,
            shape: crateShape,
            position: new CANNON.Vec3(position.x, position.y, position.z),
            material: this.physics.defaultMaterial
        });
        this.physics.world.addBody(crateBody);
    }

    createWall(position, size) {
        const geometry = new THREE.BoxGeometry(size.x, size.y, size.z);
        const material = new THREE.MeshStandardMaterial({ color: 0x555555 });
        const wall = new THREE.Mesh(geometry, material);
        wall.position.set(position.x, position.y, position.z);
        wall.castShadow = true;
        wall.receiveShadow = true;
        this.scene.add(wall);

        const shape = new CANNON.Box(new CANNON.Vec3(size.x / 2, size.y / 2, size.z / 2));
        const body = new CANNON.Body({
            mass: 0,
            shape: shape,
            position: new CANNON.Vec3(position.x, position.y, position.z),
            material: this.physics.defaultMaterial
        });
        this.physics.world.addBody(body);
    }

    createBunker(position) {
        // Bunker is 4 walls forming a square with opening
        const wallColor = 0x4a4a4a;

        // 3 walls
        this.createWall({ x: position.x - 2.5, y: 1.5, z: position.z }, { x: 1, y: 3, z: 6 }); // Left
        this.createWall({ x: position.x + 2.5, y: 1.5, z: position.z }, { x: 1, y: 3, z: 6 }); // Right
        this.createWall({ x: position.x, y: 1.5, z: position.z + 2.5 }, { x: 6, y: 3, z: 1 }); // Back
        // Front is open for entry
    }

    createCover(position) {
        // Low wall for cover
        const height = 1.5 + Math.random() * 0.5;
        const width = 3 + Math.random() * 2;

        this.createWall(
            { x: position.x, y: height / 2, z: position.z },
            { x: width, y: height, z: 0.5 }
        );
    }

    onWindowResize() {
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }

    render() {
        this.renderer.render(this.scene, this.camera);
    }

    showVictory() {
        // Check if victory message already exists
        if (document.getElementById('victory-message')) {
            console.log('Victory message already exists, skipping');
            return;
        }
        
        // Create victory message
        const victoryElement = document.createElement('div');
        victoryElement.id = 'victory-message';
        victoryElement.innerHTML = `
            <h1>VICTORY!</h1>
            <p>You have eliminated all enemies!</p>
            <button id="restart-button">Restart Game</button>
        `;
        victoryElement.style.position = 'absolute';
        victoryElement.style.top = '50%';
        victoryElement.style.left = '50%';
        victoryElement.style.transform = 'translate(-50%, -50%)';
        victoryElement.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
        victoryElement.style.color = 'white';
        victoryElement.style.padding = '30px';
        victoryElement.style.borderRadius = '10px';
        victoryElement.style.textAlign = 'center';
        victoryElement.style.zIndex = '10';
        victoryElement.style.fontFamily = 'Arial, sans-serif';
        
        // Style the button
        const button = victoryElement.querySelector('#restart-button');
        button.style.marginTop = '20px';
        button.style.padding = '10px 20px';
        button.style.fontSize = '18px';
        button.style.backgroundColor = '#4CAF50';
        button.style.color = 'white';
        button.style.border = 'none';
        button.style.borderRadius = '5px';
        button.style.cursor = 'pointer';
        
        // Add to UI layer
        document.getElementById('ui-layer').appendChild(victoryElement);
        
        // Store reference to this World instance
        const worldInstance = this;
        
        // Add event listener to restart button using arrow function to preserve 'this'
        const handleClick = () => {
            console.log('Restart button clicked');
            worldInstance.restartGame();
        };
        
        // Make sure the button is in the DOM before adding event listener
        setTimeout(() => {
            const restartButton = document.getElementById('restart-button');
            if (restartButton) {
                restartButton.addEventListener('click', handleClick);
                console.log('Event listener attached to restart button');
            } else {
                console.error('Restart button not found in DOM');
            }
        }, 0);
        
        // Debug: Check if button is properly added
        console.log('Victory message and restart button added to DOM');
    }

    restartGame() {
        console.log('RestartGame method called');
        try {
            // Remove victory message
            const victoryMessage = document.getElementById('victory-message');
            if (victoryMessage) {
                console.log('Removing victory message');
                victoryMessage.remove();
            }
            
            // Restart the game by reloading the page
            // Use a slight delay to ensure DOM operations complete
            console.log('Reloading page in 100ms');
            setTimeout(() => {
                console.log('Page reload initiated');
                // Force a full page reload
                window.location.href = window.location.href;
            }, 100);
        } catch (error) {
            console.error('Error restarting game:', error);
            // Fallback: force reload even if there was an error
            window.location.href = window.location.href;
        }
    }
}
