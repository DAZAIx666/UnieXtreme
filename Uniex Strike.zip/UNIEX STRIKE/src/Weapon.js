import * as THREE from 'three';

export class Weapon {
    constructor(camera, scene) {
        this.camera = camera;
        this.scene = scene;

        this.shootDelay = 0.1; // Seconds between shots
        this.lastShootTime = 0;
        this.damage = 10;
        this.ammo = 30;
        this.maxAmmo = 90;

        this.recoil = { x: 0, y: 0 };
        this.recoilRecovery = 5.0;

        this.mouseButtonDown = false; // Track if mouse button is held
        this.isAiming = false; // ADS state
        this.defaultFOV = 75;
        this.aimFOV = 50; // Zoomed FOV when aiming
        this.defaultWeaponPos = { x: 0.2, y: -0.2, z: -0.5 };
        this.aimWeaponPos = { x: 0, y: -0.1, z: -0.3 }; // Centered when aiming

        this.createModel();
        this.setupInput();
    }

    createModel() {
        // Simple gun model
        const geometry = new THREE.BoxGeometry(0.1, 0.1, 0.4);
        const material = new THREE.MeshStandardMaterial({ color: 0x333333 });
        this.mesh = new THREE.Mesh(geometry, material);

        // Attach to camera so it moves with view
        this.mesh.position.set(0.2, -0.2, -0.5);
        this.camera.add(this.mesh);

        // Muzzle Flash Light
        this.flashLight = new THREE.PointLight(0xffaa00, 0, 5);
        this.flashLight.position.set(0, 0, -0.3);
        this.mesh.add(this.flashLight);
    }

    setupInput() {
        document.addEventListener('mousedown', (e) => {
            if (!document.pointerLockElement) return;

            if (e.button === 0) { // Left click - shoot
                this.mouseButtonDown = true;
            } else if (e.button === 2) { // Right click - ADS
                this.isAiming = true;
                this.updateAimState();
            }
        });

        document.addEventListener('mouseup', (e) => {
            if (e.button === 0) {
                this.mouseButtonDown = false;
            } else if (e.button === 2) {
                this.isAiming = false;
                this.updateAimState();
            }
        });

        // Prevent right-click menu
        document.addEventListener('contextmenu', (e) => {
            if (document.pointerLockElement) {
                e.preventDefault();
            }
        });
    }

    updateAimState() {
        // Smooth FOV transition
        const targetFOV = this.isAiming ? this.aimFOV : this.defaultFOV;
        this.camera.fov = targetFOV;
        this.camera.updateProjectionMatrix();

        // Move weapon position
        const targetPos = this.isAiming ? this.aimWeaponPos : this.defaultWeaponPos;
        this.mesh.position.set(targetPos.x, targetPos.y, targetPos.z);
    }

    shoot() {
        const now = performance.now() / 1000;
        if (now - this.lastShootTime < this.shootDelay || this.ammo <= 0) return;

        this.lastShootTime = now;
        this.ammo--;
        this.updateAmmoDisplay();

        // Visuals
        this.triggerMuzzleFlash();
        this.applyRecoil();

        // Raycast
        const raycaster = new THREE.Raycaster();
        raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);

        const intersects = raycaster.intersectObjects(this.scene.children, true);
        if (intersects.length > 0) {
            const hit = intersects[0];
            // Create impact effect
            this.createImpactEffect(hit.point, hit.face.normal);

            // Logic for damage
            if (hit.object.userData && hit.object.userData.type === 'enemy') {
                const enemy = hit.object.userData.entity;
                enemy.takeDamage(this.damage);
                console.log("Hit enemy! Remaining HP: " + enemy.health);
            } else if (hit.object.userData && hit.object.userData.health) {
                console.log("Hit object!");
            }
        }
    }

    triggerMuzzleFlash() {
        this.flashLight.intensity = 2;
        setTimeout(() => {
            this.flashLight.intensity = 0;
        }, 50);

        // Simple recoil animation on mesh
        this.mesh.position.z += 0.1;
        setTimeout(() => {
            this.mesh.position.z -= 0.1;
        }, 100);
    }

    applyRecoil() {
        // Add random recoil (reduced when aiming)
        const recoilMultiplier = this.isAiming ? 0.3 : 1.0; // Less recoil when ADS
        this.recoil.x += (Math.random() - 0.5) * 0.05 * recoilMultiplier;
        this.recoil.y += 0.05 * recoilMultiplier;
    }

    createImpactEffect(position, normal) {
        const geometry = new THREE.SphereGeometry(0.05, 8, 8);
        const material = new THREE.MeshBasicMaterial({ color: 0xffff00 });
        const impact = new THREE.Mesh(geometry, material);
        impact.position.copy(position);
        this.scene.add(impact);

        // Remove after a second
        setTimeout(() => {
            this.scene.remove(impact);
            geometry.dispose();
            material.dispose();
        }, 1000);
    }

    updateAmmoDisplay() {
        const el = document.getElementById('ammo-display');
        if (el) el.innerText = `${this.ammo} / ${this.maxAmmo}`;
    }

    update(dt) {
        // Auto-fire while mouse button is held
        if (this.mouseButtonDown) {
            this.shoot();
        }

        // Recoil recovery
        this.recoil.x = THREE.MathUtils.lerp(this.recoil.x, 0, this.recoilRecovery * dt);
        this.recoil.y = THREE.MathUtils.lerp(this.recoil.y, 0, this.recoilRecovery * dt);

        // Apply recoil to camera (simplified)
        // Note: Modifying camera rotation directly might conflict with PointerLockControls
        // Ideally, we modify the pitch/yaw objects inside PointerLockControls, but for now let's just shake the camera slightly or ignore camera rotation recoil to avoid fighting controls.
        // Instead, let's just animate the gun mesh for visual recoil.
    }
}
