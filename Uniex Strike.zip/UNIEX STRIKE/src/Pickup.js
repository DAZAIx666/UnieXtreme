import * as THREE from 'three';
import * as CANNON from 'cannon-es';

export class Pickup {
    constructor(world, physics, position, type = 'ammo') {
        this.world = world;
        this.physics = physics;
        this.scene = world.scene;
        this.type = type; // 'ammo', 'health', or 'shield'
        this.collected = false;
        this.respawnTime = 30; // seconds
        this.respawnTimer = 0;
        this.initialPosition = { ...position };

        this.createBody(position);
        this.createMesh();

        // Rotation animation
        this.rotationSpeed = 2;
    }

    createBody(position) {
        const radius = 0.3;
        this.body = new CANNON.Body({
            mass: 0, // Static
            shape: new CANNON.Sphere(radius),
            position: new CANNON.Vec3(position.x, position.y, position.z),
            isTrigger: true // Acts as a trigger for collision detection
        });
        this.physics.world.addBody(this.body);
        this.body.userData = { type: 'pickup', entity: this };
    }

    createMesh() {
        let geometry, material;

        if (this.type === 'ammo') {
            // Ammo box - cube
            geometry = new THREE.BoxGeometry(0.4, 0.3, 0.3);
            material = new THREE.MeshStandardMaterial({
                color: 0xffaa00,
                emissive: 0xffaa00,
                emissiveIntensity: 0.3,
                transparent: true,
                opacity: 1.0
            });
        } else if (this.type === 'health') {
            // Health pack - plus sign
            geometry = new THREE.BoxGeometry(0.5, 0.1, 0.5);
            material = new THREE.MeshStandardMaterial({
                color: 0x00ff00,
                emissive: 0x00ff00,
                emissiveIntensity: 0.3,
                transparent: true,
                opacity: 1.0
            });
        } else if (this.type === 'shield') {
            // Shield plate - hexagon-ish
            geometry = new THREE.CylinderGeometry(0.35, 0.35, 0.1, 6);
            material = new THREE.MeshStandardMaterial({
                color: 0x00aaff,
                emissive: 0x00aaff,
                emissiveIntensity: 0.4,
                transparent: true,
                opacity: 1.0,
                metalness: 0.5
            });
        }

        this.mesh = new THREE.Mesh(geometry, material);
        this.mesh.position.copy(this.body.position);
        this.mesh.castShadow = true;
        this.scene.add(this.mesh);

        // Add a cross for health packs
        if (this.type === 'health') {
            const crossGeom = new THREE.BoxGeometry(0.1, 0.5, 0.1);
            const cross = new THREE.Mesh(crossGeom, material);
            this.mesh.add(cross);
        }
    }

    checkPlayerCollision(player) {
        if (this.collected) return;

        const distance = this.body.position.distanceTo(player.body.position);
        if (distance < 1.0) { // Collection radius
            this.collect(player);
        }
    }

    collect(player) {
        if (this.collected) return;

        this.collected = true;
        this.respawnTimer = 0;

        if (this.type === 'ammo') {
            player.weapon.ammo = Math.min(player.weapon.ammo + 30, player.weapon.maxAmmo);
            player.weapon.updateAmmoDisplay();
        } else if (this.type === 'health') {
            player.health = Math.min(player.health + 50, player.maxHealth);
            player.updateHealthDisplay();
        } else if (this.type === 'shield') {
            player.shield = Math.min(player.shield + 50, player.maxShield);
            player.updateShieldDisplay();
        }

        // Visual feedback - make semi-transparent during cooldown
        this.mesh.material.opacity = 0.3;
        this.mesh.material.emissiveIntensity = 0.1;
    }

    respawn() {
        this.collected = false;
        this.mesh.material.opacity = 1.0;
        this.mesh.material.emissiveIntensity = (this.type === 'shield') ? 0.4 : 0.3;
    }

    update(dt) {
        // Handle respawn timer
        if (this.collected) {
            this.respawnTimer += dt;
            if (this.respawnTimer >= this.respawnTime) {
                this.respawn();
            }
        }

        // Rotate and bob up and down (only if not collected)
        if (!this.collected) {
            this.mesh.rotation.y += this.rotationSpeed * dt;
            this.mesh.position.y = this.body.position.y + Math.sin(Date.now() * 0.003) * 0.1;
        } else {
            // Slow rotation when collected
            this.mesh.rotation.y += this.rotationSpeed * 0.2 * dt;
        }
    }
}
