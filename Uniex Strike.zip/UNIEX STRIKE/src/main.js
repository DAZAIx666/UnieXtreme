import { Physics } from './Physics.js';
import { World } from './World.js';
import { Player } from './Player.js';
import * as THREE from 'three';

class Game {
    constructor() {
        this.physics = new Physics();
        // Pass null for player initially, set it later
        this.world = new World(this.physics, null);
        this.player = new Player(this.world, this.physics);
        this.world.setPlayer(this.player);

        this.clock = new THREE.Clock();
        this.animate();
    }

    animate() {
        requestAnimationFrame(() => this.animate());

        const dt = Math.min(this.clock.getDelta(), 0.1); // Cap dt

        this.physics.update(dt);
        this.player.update(dt);
        this.world.update(dt); // Update world (enemies)
        this.world.render();
    }
}

window.onload = () => {
    new Game();
};
