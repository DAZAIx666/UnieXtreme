import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { PointerLockControls } from 'three/examples/jsm/controls/PointerLockControls.js';
import { Weapon } from './Weapon.js';

export class Player {
    constructor(world, physics) {
        this.world = world;
        this.physics = physics;
        this.camera = world.camera;

        // Physics Body
        const radius = 0.5;
        const shape = new CANNON.Sphere(radius);
        this.body = new CANNON.Body({
            mass: 70, // kg
            shape: shape,
            position: new CANNON.Vec3(-35, 10, -35), // Spawn at elevated corner position
            material: physics.defaultMaterial
        });
        this.body.linearDamping = 0.9;
        this.body.angularDamping = 1.0; // Prevent rolling
        this.body.fixedRotation = true; // Prevent tipping over
        this.physics.world.addBody(this.body);
        this.body.userData = { type: 'player', entity: this };

        // Create a visual hitbox for enemy raycasting
        this.createHitbox();

        // Weapon
        this.weapon = new Weapon(this.camera, this.world.scene);

        // Controls
        this.controls = new PointerLockControls(this.camera, document.body);

        // Player Stats
        this.health = 100;
        this.maxHealth = 100;
        this.shield = 100; // Shield absorbs damage first
        this.maxShield = 100;

        // Input State
        this.moveForward = false;
        this.moveBackward = false;
        this.moveLeft = false;
        this.moveRight = false;
        this.canJump = false;

        this.setupInputs();
        this.setupClickToStart();

        // Contact material for jumping
        this.body.addEventListener('collide', (e) => {
            const contactNormal = new CANNON.Vec3();
            e.contact.ni.negate(contactNormal);
            const direction = contactNormal.dot(new CANNON.Vec3(0, 1, 0));
            if (direction > 0.5) {
                this.canJump = true;
            }
        });

        // Tag camera for enemy detection
        this.camera.userData = { type: 'player', entity: this };
    }

    createHitbox() {
        // Invisible mesh at player position for enemy raycast detection
        const geometry = new THREE.CapsuleGeometry(0.5, 1.5, 4, 8);
        const material = new THREE.MeshBasicMaterial({
            visible: false // Invisible but still detectable by raycasts
        });
        this.hitbox = new THREE.Mesh(geometry, material);
        this.hitbox.userData = { type: 'player', entity: this };
        this.world.scene.add(this.hitbox);
    }

    setupInputs() {
        const onKeyDown = (event) => {
            switch (event.code) {
                case 'ArrowUp':
                case 'KeyW':
                    this.moveForward = true;
                    break;
                case 'ArrowLeft':
                case 'KeyA':
                    this.moveLeft = true;
                    break;
                case 'ArrowDown':
                case 'KeyS':
                    this.moveBackward = true;
                    break;
                case 'ArrowRight':
                case 'KeyD':
                    this.moveRight = true;
                    break;
                case 'Space':
                    if (this.canJump) {
                        this.body.velocity.y = 5;
                        this.canJump = false;
                    }
                    break;
            }
        };

        const onKeyUp = (event) => {
            switch (event.code) {
                case 'ArrowUp':
                case 'KeyW':
                    this.moveForward = false;
                    break;
                case 'ArrowLeft':
                case 'KeyA':
                    this.moveLeft = false;
                    break;
                case 'ArrowDown':
                case 'KeyS':
                    this.moveBackward = false;
                    break;
                case 'ArrowRight':
                case 'KeyD':
                    this.moveRight = false;
                    break;
            }
        };

        document.addEventListener('keydown', onKeyDown);
        document.addEventListener('keyup', onKeyUp);
    }

    setupClickToStart() {
        const instructions = document.getElementById('instructions');
        const hud = document.getElementById('hud');
        const crosshair = document.getElementById('crosshair');

        instructions.addEventListener('click', () => {
            this.controls.lock();
        });

        this.controls.addEventListener('lock', () => {
            instructions.style.display = 'none';
            hud.style.display = 'flex';
            crosshair.style.display = 'block';
            this.updateHealthDisplay(); // Initialize health display
            this.updateShieldDisplay(); // Initialize shield display
        });

        this.controls.addEventListener('unlock', () => {
            instructions.style.display = 'block';
            hud.style.display = 'none'; // Optional: hide HUD when paused
            crosshair.style.display = 'none';
        });
    }

    update(dt) {
        if (this.controls.isLocked) {
            // Calculate movement direction based on camera look direction
            const inputVector = new THREE.Vector3(0, 0, 0);
            if (this.moveForward) inputVector.z -= 1;
            if (this.moveBackward) inputVector.z += 1;
            if (this.moveLeft) inputVector.x -= 1;
            if (this.moveRight) inputVector.x += 1;

            // Normalize input
            if (inputVector.length() > 0) inputVector.normalize();

            // Get camera direction (Y-rotation only)
            const direction = new THREE.Vector3();
            this.camera.getWorldDirection(direction);
            direction.y = 0;
            direction.normalize();

            const right = new THREE.Vector3();
            right.crossVectors(direction, this.camera.up).normalize();

            // Calculate force vector (we use this direction for velocity)
            const force = new THREE.Vector3();
            force.addScaledVector(direction, -inputVector.z); // Forward/Back
            force.addScaledVector(right, inputVector.x); // Left/Right

            // Velocity-based movement
            const speed = 10; // Meters per second

            if (inputVector.length() > 0) {
                const velocity = new THREE.Vector3();
                velocity.copy(force).multiplyScalar(speed);

                this.body.velocity.x = velocity.x;
                this.body.velocity.z = velocity.z;
            } else {
                // Stop horizontal movement when no input
                this.body.velocity.x = 0;
                this.body.velocity.z = 0;
            }
        }

        // Sync Camera with Physics Body
        this.camera.position.copy(this.body.position);
        this.camera.position.y += 0.6; // Eye level

        // Update hitbox position
        if (this.hitbox) {
            this.hitbox.position.copy(this.body.position);
        }

        // Update Weapon
        if (this.weapon) this.weapon.update(dt);
    }

    takeDamage(amount) {
        // Shield absorbs damage first
        if (this.shield > 0) {
            if (this.shield >= amount) {
                this.shield -= amount;
                amount = 0;
            } else {
                amount -= this.shield;
                this.shield = 0;
            }
        }

        // Remaining damage goes to health
        if (amount > 0) {
            this.health -= amount;
        }

        this.updateHealthDisplay();
        this.updateShieldDisplay();

        if (this.health <= 0) {
            this.health = 0;
            this.die();
        }
    }

    updateHealthDisplay() {
        const el = document.getElementById('health-display');
        if (el) el.innerText = `HP: ${Math.floor(this.health)}`;
    }

    updateShieldDisplay() {
        const el = document.getElementById('shield-display');
        if (el) el.innerText = `Shield: ${Math.floor(this.shield)}`;
    }

    die() {
        console.log('Player died!');
        // Respawn after delay
        setTimeout(() => {
            this.health = this.maxHealth;
            this.shield = this.maxShield; // Restore shield on respawn
            this.body.position.set(-35, 10, -35); // Respawn at starting position
            this.body.velocity.set(0, 0, 0);
            this.updateHealthDisplay();
            this.updateShieldDisplay();
        }, 2000);
    }
}
