import * as THREE from 'three';
import * as CANNON from 'cannon-es';

export class Enemy {
    constructor(world, physics, player, position) {
        this.world = world;
        this.physics = physics;
        this.player = player;
        this.scene = world.scene;

        this.health = 100;
        this.speed = 3;
        this.isDead = false;

        // Combat properties with randomization for variety - BALANCED for fair gameplay
        this.detectionRange = 25; // Range to detect and shoot player
        this.shootRange = 15 + Math.random() * 10; // 15-25 units preferred shooting distance
        this.shootDelay = 1.2 + Math.random() * 1.0; // 1.2-2.2 seconds between shots (slower)
        this.lastShootTime = 0;
        this.damage = 3 + Math.floor(Math.random() * 5); // 3-8 damage (reduced)
        this.aimAccuracy = 0.3 + Math.random() * 0.3; // 0.3-0.6 inaccuracy (MUCH worse aim)

        // Movement AI
        this.strafeDirection = Math.random() > 0.5 ? 1 : -1;
        this.strafeTimer = 0;
        this.strafeInterval = 2 + Math.random() * 2; // Change strafe every 2-4 seconds

        // Randomize stats for variety
        const difficulty = Math.random();
        if (difficulty < 0.3) {
            // Easy enemy
            this.health = 70;
            this.speed = 2.5;
            this.aimAccuracy = 0.5; // Very poor accuracy
            this.damage = 3;
        } else if (difficulty > 0.7) {
            // Hard enemy
            this.health = 130;
            this.speed = 3.5;
            this.aimAccuracy = 0.25; // Still not perfect
            this.shootDelay = 1.0;
            this.damage = 7;
        }

        this.createBody(position);
        this.createMesh();
    }

    createBody(position) {
        const radius = 0.6;
        this.body = new CANNON.Body({
            mass: 60,
            shape: new CANNON.Sphere(radius),
            position: new CANNON.Vec3(position.x, position.y, position.z),
            material: this.physics.defaultMaterial
        });
        this.body.linearDamping = 0.9;
        this.body.fixedRotation = true;
        this.physics.world.addBody(this.body);

        // Tag for raycasting/damage
        this.body.userData = { type: 'enemy', entity: this };
    }

    createMesh() {
        // Simple Capsule representation
        const geometry = new THREE.CapsuleGeometry(0.6, 1.8, 4, 8);
        const material = new THREE.MeshStandardMaterial({ color: 0xff0000 }); // Red enemies
        this.mesh = new THREE.Mesh(geometry, material);
        this.mesh.castShadow = true;
        this.scene.add(this.mesh);

        // Link mesh to body for damage detection via raycast (if raycasting against visual meshes)
        this.mesh.userData = { type: 'enemy', entity: this };

        // Add a simple "gun" indicator
        const gunGeometry = new THREE.BoxGeometry(0.1, 0.1, 0.4);
        const gunMaterial = new THREE.MeshStandardMaterial({ color: 0x333333 });
        this.gunMesh = new THREE.Mesh(gunGeometry, gunMaterial);
        this.gunMesh.position.set(0.4, 0.5, 0); // Side of enemy
        this.mesh.add(this.gunMesh);
    }

    takeDamage(amount) {
        if (this.isDead) return;

        this.health -= amount;

        // Flash white
        this.mesh.material.emissive.setHex(0xffffff);
        setTimeout(() => {
            if (!this.isDead) this.mesh.material.emissive.setHex(0x000000);
        }, 100);

        if (this.health <= 0) {
            this.die();
        }
    }

    die() {
        this.isDead = true;
        this.scene.remove(this.mesh);
        this.physics.world.removeBody(this.body);
        console.log("Enemy died");
    }

    canSeePlayer() {
        const playerPos = this.player.body.position;
        const myPos = this.body.position;
        const distance = myPos.distanceTo(playerPos);

        if (distance > this.detectionRange) return false;

        // Simple line-of-sight check using raycast
        const direction = new THREE.Vector3(
            playerPos.x - myPos.x,
            playerPos.y - myPos.y,
            playerPos.z - myPos.z
        ).normalize();

        const raycaster = new THREE.Raycaster(
            new THREE.Vector3(myPos.x, myPos.y, myPos.z),
            direction,
            0,
            distance
        );

        const intersects = raycaster.intersectObjects(this.scene.children, true);

        // Check if player is the first hit (or nothing blocks the shot)
        for (let i = 0; i < intersects.length; i++) {
            const hit = intersects[i];
            // Ignore self
            if (hit.object === this.mesh || hit.object.parent === this.mesh) continue;

            // If we hit the player first, we can see them
            if (hit.object.userData && hit.object.userData.type === 'player') {
                return true;
            }

            // If we hit something else first (obstacle), can't see player
            return false;
        }

        return true; // Nothing blocking, can see player
    }

    shootAtPlayer() {
        const now = performance.now() / 1000;
        if (now - this.lastShootTime < this.shootDelay) return;

        this.lastShootTime = now;

        // Muzzle flash effect
        this.mesh.material.emissive.setHex(0xff6600);
        setTimeout(() => {
            if (!this.isDead) this.mesh.material.emissive.setHex(0x000000);
        }, 100);

        // Raycast with inaccuracy
        const playerPos = this.player.body.position;
        const myPos = this.body.position;

        // Add inaccuracy
        const aimOffset = new THREE.Vector3(
            (Math.random() - 0.5) * this.aimAccuracy * 2,
            (Math.random() - 0.5) * this.aimAccuracy,
            (Math.random() - 0.5) * this.aimAccuracy * 2
        );

        const targetPos = new THREE.Vector3(
            playerPos.x + aimOffset.x,
            playerPos.y + aimOffset.y,
            playerPos.z + aimOffset.z
        );

        const direction = new THREE.Vector3()
            .subVectors(targetPos, new THREE.Vector3(myPos.x, myPos.y, myPos.z))
            .normalize();

        const raycaster = new THREE.Raycaster(
            new THREE.Vector3(myPos.x, myPos.y, myPos.z),
            direction,
            0,
            this.detectionRange
        );

        const intersects = raycaster.intersectObjects(this.scene.children, true);

        if (intersects.length > 0) {
            const hit = intersects[0];

            // Visual bullet trail
            this.createBulletTrail(myPos, hit.point);

            // ONLY damage player - don't hit other enemies
            if (hit.object.userData && hit.object.userData.type === 'player') {
                this.player.takeDamage(this.damage);
                console.log('Enemy hit player! Player HP:', this.player.health, 'Shield:', this.player.shield);
            }
        }
    }

    createBulletTrail(start, end) {
        const points = [
            new THREE.Vector3(start.x, start.y, start.z),
            new THREE.Vector3(end.x, end.y, end.z)
        ];
        const geometry = new THREE.BufferGeometry().setFromPoints(points);
        const material = new THREE.LineBasicMaterial({ color: 0xffff00 });
        const line = new THREE.Line(geometry, material);
        this.scene.add(line);

        // Remove after short duration
        setTimeout(() => {
            this.scene.remove(line);
            geometry.dispose();
            material.dispose();
        }, 100);
    }

    update(dt) {
        if (this.isDead) return;

        // Sync mesh with physics
        this.mesh.position.copy(this.body.position);

        const playerPos = this.player.body.position;
        const myPos = this.body.position;
        const distance = myPos.distanceTo(playerPos);

        // Rotate mesh to face player
        this.mesh.lookAt(playerPos.x, this.mesh.position.y, playerPos.z);

        // AI Behavior
        if (this.canSeePlayer()) {
            if (distance > this.shootRange) {
                // Move towards player
                const dir = new THREE.Vector3(playerPos.x - myPos.x, 0, playerPos.z - myPos.z).normalize();
                this.body.velocity.x = dir.x * this.speed;
                this.body.velocity.z = dir.z * this.speed;
            } else if (distance < this.shootRange * 0.7) {
                // Too close - back up while shooting
                const dir = new THREE.Vector3(playerPos.x - myPos.x, 0, playerPos.z - myPos.z).normalize();
                this.body.velocity.x = -dir.x * this.speed * 0.5;
                this.body.velocity.z = -dir.z * this.speed * 0.5;
                this.shootAtPlayer();
            } else {
                // In optimal range - strafe while shooting
                this.strafeTimer += dt;
                if (this.strafeTimer >= this.strafeInterval) {
                    this.strafeDirection *= -1;
                    this.strafeTimer = 0;
                    this.strafeInterval = 2 + Math.random() * 2;
                }

                // Calculate strafe direction (perpendicular to player)
                const toPlayer = new THREE.Vector3(playerPos.x - myPos.x, 0, playerPos.z - myPos.z);
                const strafeDir = new THREE.Vector3(-toPlayer.z, 0, toPlayer.x).normalize();

                this.body.velocity.x = strafeDir.x * this.strafeDirection * this.speed * 0.7;
                this.body.velocity.z = strafeDir.z * this.strafeDirection * this.speed * 0.7;

                this.shootAtPlayer();
            }
        } else {
            // Move towards player (searching behavior)
            const dir = new THREE.Vector3(playerPos.x - myPos.x, 0, playerPos.z - myPos.z).normalize();
            this.body.velocity.x = dir.x * this.speed;
            this.body.velocity.z = dir.z * this.speed;
        }
    }
}
